#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021-11-29 17:07
# @Author  : hxinaa
from sys import argv
from typing import List,Tuple
# from sumeval.metrics.bleu import BLEUCalculator
from sumeval.metrics.rouge import RougeCalculator
import pandas as pd
import torch
from torch import nn, Tensor
import torch.nn.functional as F
from torch.nn import TransformerEncoder, TransformerEncoderLayer
from torch.utils.data import dataset
import math
class SumEvaluator:
    """Evaluator class for generation.
    A wrapper class of sumeval library
    """

    def __init__(self,
                 metrics: List[str] = ["rouge_1",
                                       "rouge_2",
                                       "rouge_l",
                                       "rouge_be",
                                       "bleu"],
                 lang: str = "en",
                 stopwords: bool = True,
                 stemming: bool = True,
                 use_porter=True):
        if use_porter:
            self.rouge = RougeCalculator(stopwords=stopwords,
                                         stemming=stemming,
                                         lang="en-porter")
        else:
            self.rouge = RougeCalculator(stopwords=stopwords,
                                         stemming=stemming,
                                         lang="en")
        # self.bleu = BLEUCalculator(lang=lang)
        self.metrics = sorted(metrics)

    def eval(self,
             true_gens: List[str],
             pred_gens: List[str]):

        assert len(true_gens) == len(pred_gens)

        eval_list = []
        colnames = []
        for i, (true_gen, pred_gen) in enumerate(zip(true_gens, pred_gens)):
            evals = []

            # # BLEU
            # if "bleu" in self.metrics:
            #     bleu_score = self.bleu.bleu(pred_gen,
            #                                 true_gen) / 100.0  # align scale
            #     evals.append(bleu_score)

            # ROUGE
            if "rouge_1" in self.metrics:
                rouge_1 = self.rouge.rouge_n(
                    summary=pred_gen,
                    references=[true_gen],
                    n=1)
                evals.append(rouge_1)

            if "rouge_2" in self.metrics:
                rouge_2 = self.rouge.rouge_n(
                    summary=pred_gen,
                    references=[true_gen],
                    n=2)
                evals.append(rouge_2)

            if "rouge_be" in self.metrics:
                rouge_be = self.rouge.rouge_be(
                    summary=pred_gen,
                    references=[true_gen])
                evals.append(rouge_be)

            if "rouge_l" in self.metrics:
                rouge_l = self.rouge.rouge_l(
                    summary=pred_gen,
                    references=[true_gen])
                evals.append(rouge_l)

            eval_list.append([pred_gen, true_gen] + evals)
        eval_df = pd.DataFrame(eval_list,columns=["pred","true"] + self.metrics)
        return eval_df

class PositionalEncoding(nn.Module):

    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 5000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)

        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        pe = torch.zeros(max_len, 1, d_model)
        pe[:, 0, 0::2] = torch.sin(position * div_term)
        pe[:, 0, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)

    def forward(self, x: Tensor) -> Tensor:
        """
        Args:
            x: Tensor, shape [seq_len, batch_size, embedding_dim]
        """
        x = x + self.pe[:x.size(0)]
        return self.dropout(x)

class TransformerModel(nn.Module):
    def __init__(self,
                 in_vocab_size: int,
                 emb_size: int,
                 out_vocab_size: int,
                 pretrained_vectors: torch.Tensor = None,
                 shared_word_embedding: bool = False,
                 *args, **kwargs):
        super(TransformerModel, self).__init__()
        self.in_vocab_size = in_vocab_size
        self.out_vocab_size = out_vocab_size
        self.emb_size = emb_size
        self.in_emb = nn.Embedding(self.in_vocab_size,
                                   self.emb_size)
        self.in_pos = PositionalEncoding(self.emb_size)

        # Shared word&pos embedding
        if shared_word_embedding:
            if in_vocab_size != out_vocab_size:
                raise ValueError("Unable to use shared word/pos embeddings ",
                                 "if in_vocab_size != out_vocab_size.")
            self.out_emb = self.in_emb
            self.out_pos = self.in_pos
        else:
            self.out_emb = nn.Embedding(self.out_vocab_size,
                                        self.emb_size)
            self.out_pos = PositionalEncoding(self.emb_size)

        if pretrained_vectors is not None:
            self.in_emb.weight.data.copy_(pretrained_vectors)
            self.out_emb.weight.data.copy_(pretrained_vectors)

        self.transformer = nn.Transformer(self.emb_size,
                                          **kwargs)
        self.linear = nn.Linear(self.emb_size,
                                self.out_vocab_size)

    def in_embed(self,src):
        return self.in_pos(self.in_emb(src))

    def out_embed(self,tgt):
        return self.out_pos(self.out_emb(tgt))

    def encode(self,src,src_mask=None,src_key_padding_mask=None):
        memory = self.transformer.encoder(self.in_embed(src),mask=src_mask,src_key_padding_mask=src_key_padding_mask)
        return memory


    def decode(self,tgt,memory,tgt_mask=None,memory_mask=None,tgt_key_padding_mask=None,memory_key_padding_mask=None):
        output = self.transformer.decoder(self.out_embed(tgt),memory,
                                          tgt_mask=tgt_mask,
                                          memory_mask=memory_mask,
                                          tgt_key_padding_mask=tgt_key_padding_mask,
                                          memory_key_padding_mask=memory_key_padding_mask)
        return output

    def forward(self,src,tgt,*args, **kwargs):
        out = self.transformer(self.in_embed(src),
                               self.out_embed(tgt),
                               *args,
                               **kwargs)
        out = self.linear(out)
        return out

    def generate(self,
                 src: torch.Tensor,
                 maxlen: int,
                 bos_index: int,
                 pad_index: int):
        # Obtain device information
        device = next(self.parameters()).device
        _, batch_size = src.shape
        src_key_padding_mask = (src == pad_index).T  # batch_size x srclen
        memory = self.encode(src,src_key_padding_mask=src_key_padding_mask)

        # <BOS> tgt seq for generation
        tgt = torch.LongTensor(maxlen, batch_size).fill_(pad_index).to(device)
        tgt[0, :] = torch.LongTensor(batch_size).fill_(bos_index).to(device)

        for i in range(1, maxlen):
            tgt_key_padding_mask = (tgt[:i, :] == pad_index).T  # batch_size x len(tgt)
            tgt_mask = self.transformer.generate_square_subsequent_mask(i).to(device)
            decode_prob = self.decode(tgt[:i, :],
                                      memory,
                                      tgt_mask=tgt_mask,
                                      tgt_key_padding_mask=tgt_key_padding_mask)
            pred_prob = self.linear(decode_prob)
            decode_output = pred_prob.argmax(2)
            tgt[i, :] = decode_output[-1, :]
        return tgt

if __name__ == '__main__':
    print("main")