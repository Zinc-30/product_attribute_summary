#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2022-01-14 14:32
# @Author  : hxinaa
from sys import argv
import logging
import json
import gzip

def naive_cluster(file):
    ans = {}
    cnt = {}
    for line in open(file):
        x = json.loads(line)
        asin = x['asin']
        for j in range(len(x['aspects'])):
            aspect = x['aspects'][j]
            opinion = x['sentiments'][j]
            if asin not in ans:
                ans[asin] = {}
                cnt[asin] = {}
            if aspect not in ans[asin]:
                ans[asin][aspect] = 0
                cnt[asin][aspect] = 0
            if opinion == 'good':
                cnt[asin][aspect] += 1
                ans[asin][aspect] += 1
            if opinion == 'bad':
                ans[asin][aspect] += 0
                cnt[asin][aspect] += 1
    for asin in ans:
        for aspect in ans[asin]:
            ans[asin][aspect] = ans[asin][aspect]*1.0/cnt[asin][aspect]
    with open("../../data/result.txt",'w') as fout:
        for asin in ans:
            for aspect in ans[asin]:
                # print(asin,aspect,ans[asin][aspect])
                fout.write("{\"asin\": \""+asin+"\", \"aspect\": \""+aspect+"\", \"opinion\" :"+str(ans[asin][aspect])+"}\n")


if __name__ == '__main__':
    data = naive_cluster("../../data/test_result.json")