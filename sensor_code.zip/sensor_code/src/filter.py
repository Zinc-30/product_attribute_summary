import json
from nltk import pos_tag
from nltk.sentiment.vader import SentimentIntensityAnalyzer


def load_dict(jsonl_path):
    # print('loading {},,'.format(jsonl_path))
    with open(jsonl_path) as f:
        for line in f:
            line = json.loads(line)
    return line


def filter_dataset(dataset, filter_word):
    dataset_new = []
    for product in dataset:
        d = {'asin': product['asin'], 'info': []}
        for user in product['info']:
            pair_list = []
            user_dict = {'rid': user['rid']}
            for sents in user['st_pairs']:
                for pairs in sents:
                    if pairs[1].lower() in filter_word or pairs[0].lower() in filter_word:
                        continue
                    elif len(pairs[0]) <= 1 or len(pairs[1]) <= 1:
                        continue
                    elif len(pairs[0]) == 2:
                        if '\'' in pairs[0]:
                            continue
                    elif len(pairs[1]) == 2:
                        if '\'' in pairs[1]:
                            continue
                    else:
                        pair_list.append(pairs)
            if pair_list:
                user_dict['st_pairs'] = pair_list
                d['info'].append(user_dict)
        dataset_new.append(d)
    return dataset_new


def dump_lines(dic, out_path):
    with open(out_path, 'w') as fout:
        json.dump(dic, fout)
        fout.write('\n')


def merge_pairs(dataset):
    pairs_dict = {}
    for product in dataset:
        for info in product['info']:
            pairs_list = []
            for pairs in info['st_pairs']:
                if pairs[1].lower() in pairs_dict:
                    if pairs[0].lower() not in pairs_dict[pairs[1].lower()]:
                        pairs_dict[pairs[1].lower()].append(pairs[0].lower())
                        pairs_list.append([pairs[0].lower(), pairs[1].lower()])
                else:
                    pairs_dict[pairs[1].lower()] = [pairs[0].lower()]
                    pairs_list.append([pairs[0].lower(), pairs[1].lower()])
            info['st_pairs'] = pairs_list
    return pairs_dict


def tag_words(pairs_dict: dict):
    filtered_dict = {}
    droped_list = []
    sid = SentimentIntensityAnalyzer()
    for aspect, word_list in pairs_dict.items():
        tagged_word_list = []
        aspect_tag = pos_tag([aspect])
        if aspect_tag[0][1] != 'NN':
            print(aspect + 'is not NN')
            droped_list.append(aspect)
            continue
        for words in word_list:
            tagged_word = pos_tag([words])
            if tagged_word[0][1] == 'JJ':
                combined_str = words + ' ' + aspect
                senti = sid.polarity_scores(combined_str)
                del senti['compound']
                max_polarity = max(senti, key=senti.get)
                if max_polarity == 'neg':
                    max_polarity_score = -senti[max_polarity]
                elif max_polarity == 'neu':
                    max_polarity_score = senti[max_polarity] / 2
                else:
                    max_polarity_score = senti[max_polarity]
                tagged_word_list.append([words, max_polarity_score])

        if tagged_word_list:
            tagged_word_list = sorted(tagged_word_list, key=(lambda x: abs(x[1])), reverse=True)
            filtered_dict[aspect] = tagged_word_list
    return filtered_dict


def drop_data(dataset: dict, threshold: int):
    if threshold <= 1:
        return dataset
    dataset_cp = dataset.copy()
    for key, value in dataset.items():
        if len(value) < threshold:
            del dataset_cp[key]
    return dataset_cp


if __name__ == '__main__':
    filter_word = ['me', 'i', 'you', 'he', 'she', 'they', 'it', 'that', 'them', 'their', 'this', 'him', 'her', 'time',
                   'thing', 'happy']
    dataset = load_dict('ST_paired_data.json')
    dataset_new = filter_dataset(dataset, filter_word)
    pairs_dict = merge_pairs(dataset_new)
    tagged_dict = tag_words(pairs_dict)
    tagged_dict_filtered = drop_data(tagged_dict, 10)
    dump_lines(tagged_dict_filtered, './tagged_pair.json')
    print('finished')
