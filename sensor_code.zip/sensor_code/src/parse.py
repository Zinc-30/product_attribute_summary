import requests
from pathlib import Path
import json
import tqdm
import spacy
from elasticsearch import Elasticsearch, helpers
nlp = spacy.load('en_core_web_sm')
es = Elasticsearch("localhost:9201")

def preprocess(d):
    data_dict_total = []
    for path in Path(d).rglob('*.txt'):
        with open(path, "r", encoding='utf-8') as fname:
            first_line = True
            second_line = False
            rid, rate, vote = -2, -2, -2
            sent_list_total = []
            sent_list = []
            other_info_dict = {}
            for line in fname:
                line = line.strip()
                if line[:7] == '[START]':
                    l = line.strip('\n').split('|')
                    rid, rate, vote = l[0], l[1], l[2]
                else:
                    sent_list.append(line.strip('\n'))
                # if line[:7]!= '[START]':
                #     if second_line:
                #         l = line.strip('\n').split('|')
                #         rid, rate, vote = l[0], l[1], l[2]
                #         other_info_dict['rid'] = rid
                #         other_info_dict['rate'] = rate
                #         if str(vote) == '-1':
                #             vote = '0'
                #         other_info_dict['vote'] = vote
                #         second_line = False
                #     else:
                #         sent_list.append(line.strip('\n'))
                # else:
                #     if first_line:
                #         first_line = False
                #         second_line = True
                #         continue
                #     else:
                #         other_info_dict['sent'] = sent_list
                #         sent_list = []
                #         sent_list_total.append(other_info_dict)
                #         other_info_dict = {}
                #         second_line = True
            data_dict = {'asin': path.stem, 'info': sent_list}
            data_dict_total.append(data_dict)
    return data_dict_total


def dump_lines(dic, out_path):
    with open(out_path, 'w') as fout:
        json.dump(dic, fout)
        fout.write('\n')


def parse(sentence):
    # data_dict = {'data': sentence}
    loc = locals()
    # text = requests.post('http://[::]:9000/?properties={"annotators":"depparse","outputFormat":"json"}',
    #                      data=sentence).text
    ans = nlp(sentence)
    extracted_tuple = []
    for tok in ans:
        # print(tok.text,tok.tag_,tok.dep_,[c for c in tok.children])
        if tok.dep_ == 'nsubj':
            adj = ""
            for x in tok.children:
                if x.dep_ == 'amod' and x.tag_=='JJ':
                    adj = adj + " "+ x.text
            if len(adj)>0:
                extracted_tuple.append((adj.lstrip(), tok.text))
    return extracted_tuple

def main():
    data_dict_total = preprocess('../../data/computer_data_preprocessed')
    ans_total = []
    for data in tqdm.tqdm(data_dict_total):
        ans = {"ASIN":data['asin']}
        total_tuples = {}
        cnt = {}
        for sentence in data['info']:
            result = parse(sentence)
            if len(result)>0:
                # print(result)
                for stpari in result:
                    if stpari[1] in total_tuples:
                        if stpari[0] in cnt[stpari[1]]:
                            cnt[stpari[1]][stpari[0]]+=1
                        else:
                            total_tuples[stpari[1]].append(stpari[0])
                            cnt[stpari[1]][stpari[0]] = 1
                    else:
                        total_tuples[stpari[1]] = [stpari[0]]
                        cnt[stpari[1]] = {}
                        cnt[stpari[1]][stpari[0]] = 1
        ans["opinion"] = {}
        for aspect in total_tuples:
            ans["opinion"][aspect] = []
            for opn in total_tuples[aspect]:
                ans["opinion"][aspect].append((opn,cnt[aspect][opn]))
        ans_total.append(ans)
    dump_lines(ans_total,"../../output/pattern_output.json")

def get_reviews_for_pid(pid):
    """
    :param pid: product id
    :return: a set of reviews sentences
    """
    body = {"bool": {"must": {"match": {"asin": pid}}}}
    res = es.search(index="amazon_review", query=body)
    sent_list = []
    for x in res['hits']['hits']:
        sent_list.append(x['_source']['reviewText'])
    # print(sent_list)
    return sent_list

def extract_stpair_for_pid(pid):
    """
    :param pid: product id
    :return: extracted st pairs for a product
    """
    sent_list = get_reviews_for_pid(pid)
    ans = {"ASIN": pid}
    total_tuples = {}
    cnt = {}
    for sent in sent_list:
        result = parse(sent)
        if len(result) > 0:
            # print(result)
            for stpari in result:
                if stpari[1] in total_tuples:
                    if stpari[0] in cnt[stpari[1]]:
                        cnt[stpari[1]][stpari[0]] += 1
                    else:
                        total_tuples[stpari[1]].append(stpari[0])
                        cnt[stpari[1]][stpari[0]] = 1
                else:
                    total_tuples[stpari[1]] = [stpari[0]]
                    cnt[stpari[1]] = {}
                    cnt[stpari[1]][stpari[0]] = 1
    ans["opinion"] = {}
    for aspect in total_tuples:
        ans["opinion"][aspect] = []
        for opn in total_tuples[aspect]:
            ans["opinion"][aspect].append((opn, cnt[aspect][opn]))
    return ans

def extract_stpair_for_pids(pids):
    """

    :param pids: a list of pids
    :return: a json file
    """
    ans_total = []
    for pid in tqdm.tqdm(pids):
        ans = extract_stpair_for_pid(pid)
        ans_total.append(ans)
    dump_lines(ans_total, "../../output/pattern_output1.json")


if __name__ == '__main__':
    pids = []
    for pid in open('../../output/demo_ids.txt'):
        pids.append(pid)
    extract_stpair_for_pids(pids[:3000])
