# Copyright 2019 Megagon Labs, Inc. and the University of Edinburgh. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

import os
import commentjson

import pandas as pd

from sumeval.metrics.rouge import RougeCalculator
# from sumeval.metrics.bleu import BLEUCalculator

class SumEvaluator:
    """Evaluator class for generation.
    A wrapper class of sumeval library
    """

    def __init__(self, metrics = ["rouge_1","rouge_2","rouge_l"],lang= "en_core_web_sm", stopwords= True, stemming= True, use_porter=True):
        if use_porter:
            self.rouge = RougeCalculator(stopwords=stopwords,
                                         stemming=stemming,
                                         lang=lang)

        else:
            self.rouge = RougeCalculator(stopwords=stopwords,
                                         stemming=stemming,
                                         lang=lang)
        # self.bleu = BLEUCalculator(lang=lang)
        self.metrics = sorted(metrics)

    def eval(self,true_gens,pred_gens):

        assert len(true_gens) == len(pred_gens)
        eval_list = []
        colnames = []
        for i, (true_gen, pred_gen) in enumerate(zip(true_gens, pred_gens)):
            evals = []

            # BLEU
            # if "bleu" in self.metrics:
            #     bleu_score = self.bleu.bleu(pred_gen,true_gen) / 100.0  # align scale
            #     evals.append(bleu_score)

            # ROUGE
            if "rouge_1" in self.metrics:
                rouge_1 = self.rouge.rouge_n(
                    summary=pred_gen,
                    references=[true_gen],
                    n=1)
                evals.append(rouge_1)

            if "rouge_2" in self.metrics:
                rouge_2 = self.rouge.rouge_n(
                    summary=pred_gen,
                    references=[true_gen],
                    n=2)
                evals.append(rouge_2)

            if "rouge_be" in self.metrics:
                rouge_be = self.rouge.rouge_be(
                    summary=pred_gen,
                    references=[true_gen])
                evals.append(rouge_be)

            if "rouge_l" in self.metrics:
                rouge_l = self.rouge.rouge_l(
                    summary=pred_gen,
                    references=[true_gen])
                evals.append(rouge_l)

            eval_list.append([pred_gen, true_gen] + evals)
        eval_df = pd.DataFrame(eval_list,columns=["pred","true"] + self.metrics)
        return eval_df

def rouge_result(pred,true):
    """
    :param pred: a list of pred summary sentences
    :param true: a list of true summary sentences
    :return:
    """
    evaluator = SumEvaluator()
    ans = evaluator.eval(pred,true)
    print(ans)

    return ans.mean(axis=0)

if __name__ == "__main__":
    s1 = ["this is a good resturantu", "this is a good resturantu", "this is a good resturantu"]
    s2 = ["this is not a good resutruant", "this is a good shop", "this is a good resturantu"]
    print(rouge_result(s1,s2)["rouge_1"])
