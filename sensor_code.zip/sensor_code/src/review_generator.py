#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021-11-22 16:09
# @Author  : hxinaa
from sys import argv

import commentjson
import os
from torchtext.legacy.data import Field, RawField, TabularDataset, BucketIterator
import dill
import torch
import time
import logging
import math
from typing import Tuple
from torch import nn, Tensor
import torch.nn.functional as F
from torch.nn import TransformerEncoder, TransformerEncoderLayer
from torch.utils.data import dataset
from torchtext.data.utils import get_tokenizer
from torchtext.vocab import build_vocab_from_iterator

from torch.utils.data.dataset import Dataset
from torch.utils.data import DataLoader
from torch.nn.utils.rnn import pad_sequence
from models import SumEvaluator,TransformerModel
import pandas as pd

class ReviewDataset(Dataset):
    def __init__(self,csv_file):
        self.data = pd.read_csv(csv_file,header=0)
        # print(self.data)
        self.input_text = self.data["input_text"]
        self.review = self.data["review"]

    def __getitem__(self, index):
        return (self.input_text.iloc[index], self.review.iloc[index])

    def __len__(self):
        return len(self.data.index)


def train_model(train_filepath,model_filepath):
    def data_iter(filepath):
        df = pd.read_csv(filepath)
        for row in df:
            yield row['input_text'], row['review']

    logging.warning("init---")
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logging.warning("device is "+device.__str__())
    train_iter = ReviewDataset(train_filepath)
    logging.warning("finish build dataset")
    tokenizer = get_tokenizer('basic_english')
    start_time = time.time()
    count = 0
    for (intext, review) in train_iter:
        if count % 10==0:
            logging.warning(count)
            logging.warning(review)
            logging.warning(intext)
        vocab = build_vocab_from_iterator(map(tokenizer, review), specials=['<unk>', '<BOS>', '<EOS>', '<PAD>'])
        count+=1
    logging.warning("time cost {}".format(time.time()-start_time))
    logging.warning("finish vocab")
    vocab.set_default_index(vocab['<unk>'])
    print("The length of the new vocab is", len(vocab))
    print("The index of '<BOS>' is", vocab['<BOS>'])

    text_transform = lambda x: [vocab['<BOS>']] + [vocab[token] for token in tokenizer(x)] + [vocab['<EOS>']]

    def collate_batch(batch):
        intext_list, outtext_list = [], []
        for (_intext, _review) in batch:
            in_text = torch.tensor(text_transform(_intext))
            intext_list.append(in_text)
            out_text = torch.tensor(text_transform(_review))
            outtext_list.append(out_text)
        return pad_sequence(intext_list, padding_value=vocab['<PAD>']), pad_sequence(outtext_list, padding_value=vocab['<PAD>'])


    #
    #
    train_dataloader = DataLoader(list(train_iter), batch_size=8, shuffle=True, collate_fn=collate_batch)
    # sumeval evaluator
    evaluator = SumEvaluator(metrics=['rouge_1'],stopwords=False,lang="en")
    vocab_size = len(vocab)  # size of vocabulary
    emb_size = 200  # embedding dimension
    # d_hid = 200  # dimension of the feedforward network model in nn.TransformerEncoder
    # nlayers = 2  # number of nn.TransformerEncoderLayer in nn.TransformerEncoder
    # nhead = 2  # number of heads in nn.MultiheadAttention
    # dropout = 0.2  # dropout probability
    model = TransformerModel(vocab_size, emb_size, vocab_size).to(device)
    criterion = nn.CrossEntropyLoss(ignore_index=vocab["<pad>"],reduction="none").to(device)  # mean
    optimizer = torch.optim.SGD(model.parameters(), lr=5.0)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 1.0, gamma=0.95)

    num_epoch = 1
    for epoch in range(num_epoch):
        training_loss = 0.0
        start_time = time.time()
        model.train()

        for batch_idx, (in_text,out_text) in enumerate(train_dataloader):
            src_seqlen, b_size = in_text.shape
            tgt_seqlen, _ = out_text.shape
            in_text = in_text.to(device)
            out_text = out_text.to(device)
            optimizer.zero_grad()

            # Mask preparation
            src_key_padding_mask = (in_text == vocab["<pad>"]).T  # b_size x srclen
            tgt_key_padding_mask = (out_text == vocab["<pad>"]).T  # b_size x tgtlen
            tgt_mask = nn.Transformer.generate_square_subsequent_mask(src_seqlen).to(device)

            pred = model(in_text,out_text,tgt_mask=tgt_mask,
                         src_key_padding_mask=src_key_padding_mask,
                         tgt_key_padding_mask=tgt_key_padding_mask)

            print(pred.shape)
            print(out_text.shape)
            targets = torch.cat([out_text[1:, :],torch.LongTensor(vocab["<pad>"],b_size).fill_(1).to(device)], axis=0)
            optimizer.zero_grad()
            loss = criterion(pred,targets)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
            optimizer.step()
            training_loss += loss.data.item()
            if batch_idx % 500 == 0:
                print("Train: {} loss={} time cost={}".format(batch_idx, training_loss,time.time()-start_time))
        torch.save(model.state_dict(),model_filepath.replace(".pt", "_epoch-{}.pt".format(epoch)))

# def test(model_filepath,data_filepath):
#     vocab = {}
#     ntokens = len(vocab)  # size of vocabulary
#     emsize = 200  # embedding dimension
#     d_hid = 200  # dimension of the feedforward network model in nn.TransformerEncoder
#     nlayers = 2  # number of nn.TransformerEncoderLayer in nn.TransformerEncoder
#     nhead = 2  # number of heads in nn.MultiheadAttention
#     dropout = 0.2  # dropout probability
#     device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#     model = TransformerModel(ntokens, emsize, nhead, d_hid, nlayers, dropout).to(device)
#     model.load_state_dict(torch.load(model_filepath,map_location=device))
#
#     # Mask preparation
#     src_key_padding_mask = (in_text == vocab.stoi["<pad>"]).T  # b_size x srclen
#     tgt_key_padding_mask = (batch.out_text == vocab.stoi["<pad>"]).T  # b_size x tgtlen
#     tgt_mask = model.transformer.generate_square_subsequent_mask(tgt_seqlen).to(device)
#
#     pred = model(batch.in_text,tgt_mask=tgt_mask,




if __name__ == '__main__':
    config_file = "default.json"
    with open(config_file, "r") as file:
        configs = commentjson.loads(file.read())
    dir_filepath = os.path.join("./data", configs["p_name"])

    train_filepath = os.path.join(dir_filepath, "demo.csv")

    model_filepath = os.path.join(dir_filepath,"xin_model.pt")
    logging.warning("init xin")
    train_model(train_filepath,model_filepath)


    # fields = {"eid": ("eid", ID),
    #           "rid": ("rid", ID),
    #           "review": ("out_text", OUT_TEXT),
    #           "input_text": ("in_text", IN_TEXT)}
    # train = TabularDataset(path=train_filepath,
    #                        format="csv",
    #                        fields=[("eid",)])